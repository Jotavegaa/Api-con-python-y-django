from django import forms
from .models import Gender, Person, Publisher,Cantidad

class PersonForm(forms.ModelForm):
  gender = forms.ModelChoiceField(
    queryset=Gender.objects.all(), 
    empty_label="Seleccione su genero")

  class Meta:
    model = Person
    fields = ('name', 'author', 'fecha', 'gender')
  class Meta2:
    model = Publisher
    fields = ('name')
  class Meta3:
    model: Cantidad
    fields = ('quantity')