from django.db import models

# Create your models here.

# Definicion de un clase [modelo] de atributos fijos.
class Gender(models.Model):
  name = models.CharField(max_length = 20, unique = True)

  def __str__(self):
    return self.name

# Uso del anterior para un atributo que no queremos sea escrito si no seleccionado.
class Person(models.Model):
  name = models.CharField(max_length=50)
  author = models.CharField(max_length=50)
  fecha = models.DateField(null=False)
  gender = models.ForeignKey(Gender, on_delete=models.CASCADE, null = True)

class Publisher(models.Model):
  name = models.CharField(max_length=50)
  gender = models.ForeignKey(Gender, on_delete=models.CASCADE, null = True)

class Cantidad(models.Model):
  quantity = models.IntegerField()