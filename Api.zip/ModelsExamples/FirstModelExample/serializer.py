from rest_framework import serializers
from .models import Gender, Person, Publisher, Cantidad

class GenderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Gender
        fields = '__all__'

class PersonSerializer(serializers.ModelSerializer):
    class Meta:
        model = Person
        fields = '__all__'

class PublisherSerializer(serializers.ModelSerializer):
    class Meta:
        model = Publisher
        fields = '__all__'

class CantidadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cantidad
        fields = '__all__'
