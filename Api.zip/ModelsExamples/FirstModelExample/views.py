from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse
from rest_framework import generics
from rest_framework.response import Response
from .models import Person, Publisher
from .forms import PersonForm
from .serializer import PersonSerializer

# Views para renderizar plantillas HTML
def person_list(request):
    persons = Person.objects.all()
    return render(request, 'FirstModelExample/person_list.html', { 'person_list': persons })

def person_detail(request, pk):
    person = get_object_or_404(Person, pk=pk)
    return render(request, 'FirstModelExample/person_detail.html', { 'person': person })

def person_new(request):
    if request.method == "POST":
        form = PersonForm(request.POST)
        if form.is_valid():
            person = form.save()
            return redirect('person_detail', pk=person.pk)
    else:
        form = PersonForm()
    return render(request, 'FirstModelExample/person_edit.html', { 'form': form })

def person_edit(request, pk):
    person = get_object_or_404(Person, pk=pk)
    if request.method == "POST":
        form = PersonForm(request.POST, instance=person)
        if form.is_valid():
            form.save()
            return redirect('person_detail', pk=person.pk)
    else:
        form = PersonForm(instance=person)
    return render(request, 'FirstModelExample/person_edit.html', { 'form': form })

def person_delete(request, pk):
    person = get_object_or_404(Person, pk=pk)
    if request.method == "POST":
        person.delete()
        return redirect('person_list')
    return render(request, 'FirstModelExample/person_detail.html', { 'person': person })

# Vistas de la API utilizando Django Rest Framework
class PersonListAPIView(generics.ListCreateAPIView):
    queryset = Person.objects.all()
    serializer_class = PersonSerializer

class PersonDetailAPIView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Person.objects.all()
    serializer_class = PersonSerializer
