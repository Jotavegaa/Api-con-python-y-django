from django.urls import path
from . import views
from .views import PersonListAPIView, PersonDetailAPIView

urlpatterns = [
    # URLs para las vistas que renderizan plantillas HTML
    path('', views.person_list, name='person_list'),
    path('person/<int:pk>/', views.person_detail, name='person_detail'),
    path('person/new/', views.person_new, name='person_new'),
    path('person/<int:pk>/edit/', views.person_edit, name='person_edit'),
    path('person/delete/<int:pk>/', views.person_delete, name='person_delete'),

    # URLs para las vistas de la API utilizando Django Rest Framework
    path('api/v1/person/', PersonListAPIView.as_view(), name='api_person_list'),
    path('api/v1/person/<int:pk>/', PersonDetailAPIView.as_view(), name='api_person_detail'),
]
